import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      Hello world AWS Beanstalk by Reactjs.
    </div>
  );
}

export default App;

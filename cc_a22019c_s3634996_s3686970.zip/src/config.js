export default {
    apiGateway: {
        REGION: 'us-east-1',
        URL:'https://nx7eiabksh.execute-api.us-east-1.amazonaws.com/dev',
    },
    cognito:{
        REGION:'us-east-1',
        USER_POOL_ID:'us-east-1_9yHEahPWy',
        APP_CLIENT_ID: '1ttne14j3121llt108u9q9pco9',
        IDENTITY_POOL_ID:'us-east-1:acf4cbb3-1e98-42e8-853d-cccded0ed0c8'
    }
    }

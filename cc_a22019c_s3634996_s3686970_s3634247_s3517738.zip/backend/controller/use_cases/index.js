const requestEquipment = require('./request-equipment')

module.exports ={
    requestEquipment: requestEquipment
}
export default {
    apiGateway: {
        REGION: 'us-east-1',
        URL:'https://nx7eiabksh.execute-api.us-east-1.amazonaws.com/dev',
    },
    cognito:{
        REGION:'us-east-1',
        USER_POOL_ID:'us-east-1_AVkhlsemI',
        APP_CLIENT_ID: '35c3p4oblr0rds72108e52h7bb',
        IDENTITY_POOL_ID:'us-east-1:2d5215d7-2b60-400d-b8a5-b7cb5f4833c9'
    }
    }
